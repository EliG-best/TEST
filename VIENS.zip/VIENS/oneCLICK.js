(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"oneCLICK_atlas_", frames: [[4269,0,1024,768],[0,0,4267,3200]]}
];


// symbols:



(lib.EGIPTIETIS = function() {
	this.initialize(ss["oneCLICK_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.parastais01 = function() {
	this.initialize(ss["oneCLICK_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Menubutton1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// HighLight
	this.instance = new lib.EGIPTIETIS();
	this.instance.setTransform(-14,-8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({_off:false},0).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14,-8,1024,768);


// stage content:
(lib.oneCLICK = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{menu:0,p1:1,p2:2,p3:3,p4:4});

	// timeline functions:
	this.frame_0 = function() {
		// Prevent HTML5 from playing the scene
		this.stop();
		
		this.btn1.addEventListener("click", move1.bind(this));
		this.btn2.addEventListener("click", move2.bind(this));
		this.btn3.addEventListener("click", move3.bind(this));
		this.btn4.addEventListener("click", move4.bind(this));
		this.btn5.addEventListener("click", move5.bind(this));
		
		function move1() {	this.gotoAndStop("menu"); }
		function move2() {	this.gotoAndStop("p1"); }
		function move3() {	this.gotoAndStop("p2"); }
		function move4() {	this.gotoAndStop("p3"); }
		function move5() {	this.gotoAndStop("p4"); }
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(5));

	// Global menu
	this.btn1 = new lib.Menubutton1();
	this.btn1.setTransform(14.2,7.75);
	new cjs.ButtonHelper(this.btn1, 0, 1, 2, false, new lib.Menubutton1(), 3);

	this.timeline.addTween(cjs.Tween.get(this.btn1).wait(5));

	// Backgrounds
	this.instance = new lib.parastais01();
	this.instance.setTransform(-1,0,0.24,0.24);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(27.2,1,1).p("AyMPyIOb/KIFfJfINGp4IDZd6");
	this.shape.setTransform(217.55,389.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).to({state:[]},1).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(511,383.8,513.2,384.2);
// library properties:
lib.properties = {
	id: '864DFB5E335EA74491E7AF547B99E246',
	width: 1024,
	height: 768,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/oneCLICK_atlas_.png?1611066740166", id:"oneCLICK_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['864DFB5E335EA74491E7AF547B99E246'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;